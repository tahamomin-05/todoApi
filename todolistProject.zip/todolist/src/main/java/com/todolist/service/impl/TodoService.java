package com.todolist.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.todolist.exception.TodoException;
import com.todolist.model.Todo;
import com.todolist.repository.TodoJpaRepository;

@Service
public class TodoService {
	@Autowired
	private TodoJpaRepository todoJpaRepository;
	public Todo addToDoList(Todo todo) {
		return todoJpaRepository.save(todo);
	}
	
	public List<Todo> getAllToDoList() {
		return todoJpaRepository.findAll();
		
	}
	
	public Todo getTodoById(Integer id) {
		Optional<Todo> todo = todoJpaRepository.findById(id);
		if(todo.isPresent())
			return todo.get();
		else
			throw new TodoException("Todo record not found for : "+id);
	}
	
	public Todo updateToDo(Todo todo, Integer id) {
		Todo existingTodo = todoJpaRepository.findById(id).orElseThrow(() -> new TodoException("Todo record not found for : "+id));
		
		existingTodo.setTodo(todo.getTodo());
		existingTodo.setStatus(todo.getStatus());
		existingTodo.setPriority(todo.getPriority());
		
		todoJpaRepository.save(existingTodo);
		return existingTodo;
		
	}
	
	public void deleteToDo(Integer id) {
		Todo existingTodo = todoJpaRepository.findById(id).orElseThrow(() -> new TodoException("Todo record not found for : "+id));
		todoJpaRepository.deleteById(id);
	}
}
