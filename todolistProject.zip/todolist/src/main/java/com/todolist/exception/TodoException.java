package com.todolist.exception;

public class TodoException extends RuntimeException{
	public TodoException(String e)
	{
		super(e);
	}
}
