package com.todolist.controller;

import java.util.List;

import org.apache.el.stream.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.todolist.exception.TodoException;
import com.todolist.model.Todo;
import com.todolist.service.impl.TodoService;

@RestController
@RequestMapping("/todos")
public class TodoController {
	@Autowired
	private TodoService todoService;
	
	@PostMapping()
	public ResponseEntity<Todo> addToDoListController(@RequestBody Todo todo) {
		return new ResponseEntity<Todo>(todoService.addToDoList(todo),HttpStatus.CREATED);
	}
	
	@GetMapping()
	public List<Todo> getAllToDoListController(){
		return todoService.getAllToDoList();
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<Todo> getTodoByIdController(@PathVariable("id") Integer id) {
		return new ResponseEntity<Todo>(todoService.getTodoById(id),HttpStatus.OK);
	}
	@PutMapping("/{id}")
	public ResponseEntity<Todo> updateToDoListController(@PathVariable("id") Integer id, @RequestBody Todo todo) {
		return new ResponseEntity<Todo>(todoService.updateToDo(todo, id),HttpStatus.OK);
	}
	@DeleteMapping("/{id}")
	public ResponseEntity<String> deleteToDoController(@PathVariable("id") Integer id) {
		todoService.deleteToDo(id);
		
		return new ResponseEntity<String>("ToDo deleted successfully", HttpStatus.OK);
	}
}
